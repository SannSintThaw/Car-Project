<body style="background-color:#f2f2f2;">
<div>
    <br>

      <center>
      <img src="img/thankss.png" width="150"/><br>
      <img src="img/ordersuccesss.gif" width="600"/><br>
     <a href="index.html"> <img src="img/home.png" width="100"/></a>
      <br>

      </center>
       </div>
</body>