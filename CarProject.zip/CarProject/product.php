<html lang="en">

<head>
    <title>Car Project</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <br>
                <a class="navbar-brand fs-2" href="#!">&nbsp;Car Showroom</a>
                <button class="navbar-toggler" type="button" data-mdb-toggle="collapse"
                    data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars"></i>
                </button>
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" xaria-current="page" href="index.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-secondary" href="product.php">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="service.html">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.html">Contact</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/3.jpeg" class="d-block w-100" height="100%" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/luxurious-car-parked-highway-with-illuminated-headlight-sunset_181624-60607.jpg"
                    class="d-block w-100" height="100%" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/495695.jpg" class="d-block w-100" height="100%" alt="...">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div><br>

    <div class="container">
       <div class="row">
    <?php
error_reporting(1);
include('connection.php');
$data="SELECT * FROM carlist ORDER BY id DESC";
$val=$con->query($data);
if ($val->num_rows > 0) {
while(list($id,$name,$price,$dis,$img) = mysqli_fetch_array($val)){
    echo "<div class='col-4'>
    <div class='card shadow-sm'>
    <img src='admin/img/$img'
    height='300' width='100%'  />
    <div class='card-body'>
        <h2 >$name</h2>
        <p style='color:Orange'>Price - $ $price </p>
        <p>$dis</p>
        <center>  <a href='order.php?name=$name&price=$price'>
        <img src='img/buy.png' width=80 class='imageee'/>
        </a></center>
    </div>
</div>
<br><br>
    </div>";
  
}}else{
    echo "<h1 colspan='8' class='text-center'>
   <b> No data available</b></h1>";
}
?>
</div>
</div>

    <center>
    <h3>Our Best Cars</h3>
    <div>
    <p>Our team of experts reviews and rates hundreds of the latest models each year to help you find your next new car. Browse our Best Car lists to discover how different models rank against each other and what our team loves and doesn't love about these top-rating vehicles.</p>
</div>
</center>

    <footer class="text-center text-white" style="background-color: #292b2c;">


        <!-- Copyright -->
        <div class="text-center p-3" style="background-color: rgba(4, 0, 0, 0.2);">
            &copy; 2024 Copyright:
            <a class="text-white" href="mailto:sannsintthaw123@gmail.com">www.sannsintthaw123@gmail.com</a>
        </div>
        <!-- Copyright -->
    </footer>



    <script src="code/jquery.min.js"></script>
    <script src="code/popper.min.js"></script>
    <script src="code/bootstrap.min.js"></script>
    <style>
.card:hover {
    transform: scale(1.05);
}

.imageee:hover {
  transform: scale(1.3);
}
        </style>
</body>

</html>